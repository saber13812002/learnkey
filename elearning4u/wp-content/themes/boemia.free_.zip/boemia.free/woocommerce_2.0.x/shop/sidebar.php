<?php get_sidebar('shop'); ?> 
    </div>
</div>